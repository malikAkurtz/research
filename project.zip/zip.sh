rm -f project.zip
zip -r project.zip . -x ".venv/*"